//Write a program to define functions for subtract, multiply, divide, factorial and reversing the digits of a number in a package, import this class in another package and use all the methodsdefined in the primary package.
package Module4;

import Module4_2.module1_2 

public class Module4_2 {
	public static void main(String[] args) throws Exception{
		Module4_2 obj=new Module4_2();
		 obj.Add(20,50);
		obj.Subtraction(50, 20);
		obj.mul(2,10);
		obj.div(10,2);
}
		
	}



	


