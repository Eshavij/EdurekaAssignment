//Write a program to print 10 even numbers and 10 odd numbers.
package Module1;

public class Module1_14 {
	public static void main(String[] args) {
		int i=0,j=1;
		while(i<20){
			System.out.println("Even numbers "+i);
		i=i+2;
		}
		while(j<20)
		{
			System.out.println("Odd numbers "+j);
			j=j+2;
		}
	

}
}
