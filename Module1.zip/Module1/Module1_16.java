//Write a program to generate tables of 10.
package Module1;

public class Module1_16 {
	public static void main(String[] args) {
		int i=1;
		int num=10;
		while(i<=10){

			 System.out.println(num+"*"+i+"="+num*i);
			 i++;
	}

	}

}
